﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_00_2033_0032
{
    partial class Program
    {
        static partial void Welcome0032()
        {
            Console.WriteLine("Hello Worlddddd");
        }
    }
}
